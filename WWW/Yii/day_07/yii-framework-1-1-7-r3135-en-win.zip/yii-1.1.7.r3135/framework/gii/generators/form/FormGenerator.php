<?php

class FormGenerator extends CCodeGenerator
{
	public $codeModel='gii.generators.form.FormCode';
}
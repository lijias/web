<?php
	class BaseController extends Controller
	{
		public function init()
		{
			session_start();
			if($_SESSION["userMsg"] == NULL)
			{
				$this->redirect("index.php?r=admin/success/index/act/nologin/rst/1");
			}
		}
	}
?>
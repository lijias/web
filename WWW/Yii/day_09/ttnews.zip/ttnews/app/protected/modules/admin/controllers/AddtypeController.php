<?php
	class AddtypeController extends BaseController
	{
		public function actionIndex()
		{
			$this->breadcrumbs = array("分类管理","添加分类");
			
			
			$data = array();
			$this->render("index",$data);
		}
		public function actionInsert()
		{
			$typeName = $_POST["typeName"];
			$newsTypes = new NewsTypes();
			$newsTypes->typeName = $typeName;
			$row = $newsTypes->save();
			
			if($row > 0)
			{
				$this->redirect("index.php?r=admin/success/index/act/addtype/rst/1");
			}
			else
			{
				$this->redirect("index.php?r=admin/success/index/act/addtype/rst/0");
			}
		}
	}
?>
<?php
	class AddnewsController extends BaseController
	{
		public function actionIndex()
		{
			$this->breadcrumbs = array("新闻管理","添加新闻");
			
			$newsTypes = NewsTypes::model()->findAll();//所有新闻分类
			
			$data = array(
				"newsTypes"=>$newsTypes
			);
			$this->render("index",$data);
		}
		//添加新闻
		public function actionInsert()
		{
			$title = $_POST["title"];
			$typeId = $_POST["typeId"];
			$myFile = $_FILES["myFile"];
			$writer = $_POST["writer"];
			$source = $_POST["source"];
			$userName = $_SESSION["userMsg"]["userName"];
			$content = $_POST["content"];
			
			$savePath = "";
			if($myFile["name"] != NULL)
			{
				$fileName = $myFile["name"];
				$pointIndex = strrpos($fileName,".");
				$ext = substr($fileName,$pointIndex);
				$fileName = time().$ext;
				$savePath = "newspicture/$fileName";
				move_uploaded_file($myFile["tmp_name"],$savePath);
			}
			$model = new NewsArticles();
			$model->content = $content;
			$model->title = $title;
			$model->typeId = $typeId;
			$model->userName = $userName;
			$model->writer = $writer;
			$model->source = $source;
			if($savePath != "")
			{
				$model->imagepath = $savePath;
			}
			$result = $model->save();
			if($result)
			{
				$db = Yii::app()->db;
				$st = $db->createCommand("update newsTypes set articleNums=articleNums+1 where typeId={$typeId}");
				$row = $st->execute();
				$this->redirect("index.php?r=admin/success/index/act/addnews/rst/1");
			}
			else
			{
				$this->redirect("index.php?r=admin/success/index/act/addnews/rst/0");
			}
		}
	}
?>
<?php
	class AdduserController extends BaseController
	{
		public function actionIndex()
		{
			$this->breadcrumbs = array("用户管理","添加用户");
			
			$data = array();
			$this->render("index",$data);
		}
		//添加用户
		public function actionInsert()
		{
			$userName = $_POST["userName"];
			$password = $_POST["password"];
			$userType = $_POST["userType"];
			$remark = $_POST["remark"];
			
			$model = new Manager();
			$model->userName = $userName;
			$model->password = $password;
			$model->userType = $userType;
			$model->remark = $remark;
			$result = $model->save();
			
			if($result)
			{
				$this->redirect("index.php?r=admin/success/index/act/adduser/rst/1");
			}
			else
			{
				$this->redirect("index.php?r=admin/success/index/act/adduser/rst/0");
			}
		}
	}
?>
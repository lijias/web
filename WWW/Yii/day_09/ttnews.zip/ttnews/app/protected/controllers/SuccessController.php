<?php
	class SuccessController extends Controller
	{
		public function init()
		{}
		public function actionIndex($act,$rst)
		{
			$this->pageTitle = "系统提示信息";
			$newsTypes = NewsTypes::model()->findAll();//所有新闻分类
			$message = NULL;
			$pageName = NULL;
			$location = NULL;
			
			if($act == "review")//评论
			{
				$articleId = $_GET["articleId"];
				if($rst == 0)
				{
					$message = "评论发表失败";
					$pageName = "查看新闻页面";
					$location = "index.php?r=news/index/articleId/{$articleId}";
				}
				else 
				{
					$message = "评论发表成功";
					$pageName = "查看新闻页面";
					$location = "index.php?r=news/index/articleId/{$articleId}";
				}
			}
			elseif ($act == "login")//管理员登陆
			{
				if($rst == 0)
				{
					$message = "验证码输入有误";
					$pageName = "天天新闻网首页";
					$location = "index.php?r=index/index";
				}
				elseif($rst == 1)
				{
					$message = "用户名或密码错误";
					$pageName = "天天新闻网首页";
					$location = "index.php?r=index/index";
				}
				elseif($rst == 2)
				{
					$message = "登陆成功，正在进入后台管理";
					$pageName = "后台管理首页";
					$location = "index.php?r=admin";
				}
			}
			
			
			$data = array(
				"newsTypes"=>$newsTypes,
				"message"=>$message,
				"pageName"=>$pageName,
				"location"=>$location
			);
			$this->render("index",$data);
		}
	}
?>
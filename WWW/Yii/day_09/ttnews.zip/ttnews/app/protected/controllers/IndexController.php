<?php
	class IndexController extends Controller
	{
		public function init()
		{}
		public function actionIndex()
		{
			$this->pageTitle = "天天新闻网-首页";
			
			$newsTypes = NewsTypes::model()->findAll();//新闻分类
			
			
			$db = Yii::app()->db;
			//新闻总数
			$st = $db->createCommand("select count(*) as newsCount from newsArticles");
			$rs = $st->queryRow();
			$newsCount = $rs["newsCount"];
			//热点要闻
			$st = $db->createCommand("select * from newsArticles a,newsTypes b where a.typeId=b.typeId order by hints desc limit 0,6");
			$hotNews = $st->queryAll();
			//每个分类下带有两条新闻
			$st = $db->createCommand("select * from newsTypes");
			$twoNewsType = $st->queryAll();
			for ($i=0;$i<count($twoNewsType);$i++)
			{
				$st = $db->createCommand("select * from newsArticles where typeId={$twoNewsType[$i]["typeId"]} order by dateandtime desc limit 0,2");
				$twoNews1 = $st->queryAll();
				$twoNews2 = array();
				for($j=0;$j<count($twoNews1);$j++)
				{
					$title = $twoNews1{$j}["title"];
					if(mb_strlen($title,"utf-8") > 15)
					{
						$title = mb_substr($title,0,14,"utf-8")."...";
					}
					$arr = array(
						"articleId"=>$twoNews1[$j]["articleId"],
						"title"=>$title
					);
					$twoNews2[] = $arr;
				}
				$twoNewsType[$i]["news"] = $twoNews2;
			}
			
			
			$data = array(
				"newsTypes"=>$newsTypes,
				"newsCount"=>$newsCount,
				"hotNews"=>$hotNews,
				"twoNewsType"=>$twoNewsType
			);
			$this->render("index",$data);
		}
		//管理员登陆
		public function actionLogin()
		{
			session_start();
			$userName = $_POST["userName"];
			$password = $_POST["password"];
			$checkCode = $_POST["checkCode"];
			$trueCode = $_SESSION["trueCode"];
			
			if($checkCode == $trueCode)
			{
				$userInfo = Manager::model()->find("userName='{$userName}' and password='{$password}'");
				if($userInfo != NULL)
				{
					$_SESSION["userMsg"] = $userInfo;
					$this->redirect("index.php?r=success/index/act/login/rst/2");
				}
				else 
				{
					$this->redirect("index.php?r=success/index/act/login/rst/1");
				}
			}
			else
			{
				$this->redirect("index.php?r=success/index/act/login/rst/0");
			}
			
		}
		//验证码方法，用于引用其他的类
		public function actions()
		{
			return array(
				//系统自带的验证码
				"mycode"=>array(
					"class"=>"system.web.widgets.captcha.CCaptchaAction",//要访问framework目录下的CCaptchaAction.php。system代表framework目录
					"width"=>70,
					"height"=>25,
					"maxLength"=>4,
					"minLength"=>4,
					"padding"=>0
				),
				//自己的验证码组件index.php?r=index/myImg
				"myImg"=>array(
					"class"=>"application.components.Image"
				)
			);
		}
	}
?>
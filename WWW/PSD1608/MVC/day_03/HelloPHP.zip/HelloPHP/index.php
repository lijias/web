<?php 
	header("content-type:text/html;charset=utf-8");
	
	//定义入口文件名
	define("INDEX_NAME","index.php");
	//定义前台、后台
	define("BIND_MODULE","default");
	
	include_once 'application/core/HelloPHP.php';
?>

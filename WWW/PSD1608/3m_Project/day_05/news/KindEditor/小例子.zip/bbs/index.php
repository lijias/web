<html>
  <head>
    <title>数据库操作</title>
    <meta http-equiv="content-type" content="text/html;charset=utf-8">
    <script language="javascript" src="kindeditor/kindeditor.js"></script>
    <script language="javascript">
    	var editor;
    	KindEditor.ready(function(e){
        	editor = e.create("[name=content]",{
            	"width":"900",
            	"height":"300",
            	"filterMode":"true",//是否过滤html代码   true：是    false：否
            	"resizeType":"1",//是否可以改变editor大小，0：不可以   1：可改高   2：无限制
            	"themeType":"default"//设置外观 themes文件夹：common、default、qq、simple
			});
		});
    </script>
  </head>
  <body>
    <form name="frm" method="post" action="">
      <table border="1" align="center" width="900">
        <tr>
          <td><textarea name="content"></textarea></td>
        </tr>
      </table>
    </form>
  </body>
</html>